
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { GoogleOAuthProvider } from '@react-oauth/google';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <GoogleOAuthProvider clientId="794231275856-slhekjlp860cut566ifr1295ii0tssf1.apps.googleusercontent.com">
    <App />
  </GoogleOAuthProvider>
);
