import React from "react";

const Settings = () => {
  return (
    <div className="settings-container">
      <h2>Settings (Feature coming soon)</h2>
    </div>
  );
};

export default Settings;
