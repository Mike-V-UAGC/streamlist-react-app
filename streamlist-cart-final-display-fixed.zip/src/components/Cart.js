
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const Cart = () => {
  const { cart, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  const safeItems = cart || [];
  const total = safeItems.reduce((acc, item) => acc + item.price, 0).toFixed(2);

  return (
    <div className="cart">
      <h2>Your Cart</h2>
      {safeItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          <ul>
            {safeItems.map((item, index) => (
              <li key={index}>
                {item.title} - ${item.price}
                <button onClick={() => removeFromCart(item)}>Remove</button>
              </li>
            ))}
          </ul>
          <h3>Total: ${total}</h3>
          <button onClick={clearCart}>Clear Cart</button>
          <button onClick={() => navigate('/checkout')}>Proceed to Checkout</button>
        </div>
      )}
    </div>
  );
};

export default Cart;
