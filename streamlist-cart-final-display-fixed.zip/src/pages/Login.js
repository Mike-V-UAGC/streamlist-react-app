
import React from 'react';
import { GoogleLogin } from '@react-oauth/google';
import { useNavigate } from 'react-router-dom';

const Login = ({ setIsAuthenticated }) => {
  const navigate = useNavigate();

  const handleSuccess = credentialResponse => {
    localStorage.setItem('user', JSON.stringify(credentialResponse));
    setIsAuthenticated(true);
    navigate('/');
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Login with Google</h2>
      <GoogleLogin onSuccess={handleSuccess} onError={() => alert('Login Failed')} />
    </div>
  );
};

export default Login;
