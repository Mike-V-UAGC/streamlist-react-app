
import React, { useState } from 'react';

const formatCardNumber = value => {
  return value.replace(/[^0-9]/g, '').replace(/(.{4})/g, '$1 ').trim();
};

const Checkout = () => {
  const [cardNumber, setCardNumber] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    localStorage.setItem('creditCard', cardNumber);
    alert('Credit Card Saved!');
  };

  return (
    <form onSubmit={handleSubmit} style={{ padding: '2rem' }}>
      <h2>Enter Credit Card Information</h2>
      <input
        type="text"
        placeholder="1234 5678 9012 3456"
        maxLength="19"
        value={cardNumber}
        onChange={e => setCardNumber(formatCardNumber(e.target.value))}
        required
      />
      <button type="submit">Submit</button>
    </form>
  );
};

export default Checkout;
