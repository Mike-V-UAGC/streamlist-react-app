import React from "react";

const Completed = () => {
  return (
    <div className="completed-container">
      <h2>Completed Tasks Page (Feature coming soon)</h2>
    </div>
  );
};

export default Completed;
